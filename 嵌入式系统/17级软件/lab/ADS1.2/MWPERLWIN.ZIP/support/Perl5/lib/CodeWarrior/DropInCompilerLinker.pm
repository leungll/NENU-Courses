=head1 NAME

CodeWarrior - Built-in CodeWarrior::DropInCompilerLinker IDE specific routines.

=head1 SYNOPSIS

	CodeWarrior::DropInCompilerLinker::CWGetContext()
	CodeWarrior::DropInCompilerLinker::CWIsPrecompiling(isPrecompiling)
	CodeWarrior::DropInCompilerLinker::CWIsAutoPrecompiling(isAutoPrecompiling)
	CodeWarrior::DropInCompilerLinker::CWIsPreprocessing(isPreprocessing)
	CodeWarrior::DropInCompilerLinker::CWIsGeneratingDebugInfo(isGenerating)
	CodeWarrior::DropInCompilerLinker::CWIsCachingPrecompiledHeaders(isCaching)
	CodeWarrior::DropInCompilerLinker::CWGetBrowseOptions(browseOptions)
	CodeWarrior::DropInCompilerLinker::CWGetBuildSequenceNumber(sequenceNumber)
	CodeWarrior::DropInCompilerLinker::CWGetTargetInfo(targetInfo)
	CodeWarrior::DropInCompilerLinker::CWSetTargetInfo(targetInfo)
	CodeWarrior::DropInCompilerLinker::CWGetTargetStorage(storage)
	CodeWarrior::DropInCompilerLinker::CWSetTargetStorage(storage)
	CodeWarrior::DropInCompilerLinker::CWGetMainFileNumber(fileNumber)
	CodeWarrior::DropInCompilerLinker::CWGetMainFileID(fileID)
	CodeWarrior::DropInCompilerLinker::CWGetMainFileSpec(fileSpec)
	CodeWarrior::DropInCompilerLinker::CWGetMainFileText(text, textLength)
	CodeWarrior::DropInCompilerLinker::CWCachePrecompiledHeader(filespec, pchhandle)
	CodeWarrior::DropInCompilerLinker::CWLoadObjectData(whichfile, objectdata)
	CodeWarrior::DropInCompilerLinker::CWFreeObjectData(whichfile, objectdata)
	CodeWarrior::DropInCompilerLinker::CWStoreObjectData(whichfile, object)
	CodeWarrior::DropInCompilerLinker::CWGetSuggestedObjectFileSpec(whichfile, fileSpec)
	CodeWarrior::DropInCompilerLinker::CWGetStoredObjectFileSpec(whichfile, fileSpec)
	CodeWarrior::DropInCompilerLinker::CWDisplayLines(nlines)
	CodeWarrior::DropInCompilerLinker::CWGetPrecompiledHeaderSpec(pchspec, target)
	CodeWarrior::DropInCompilerLinker::CWGetResourceFile(filespec)
	CodeWarrior::DropInCompilerLinker::CWPutResourceFile(prompt, name, filespec)
	CodeWarrior::DropInCompilerLinker::CWLookUpUnit(name, isdependency, unitdata, unitdatalength)
	CodeWarrior::DropInCompilerLinker::CWSBMfiles(libref)
	CodeWarrior::DropInCompilerLinker::CWStoreUnit(unitname, unitdata, dependencytag)
	CodeWarrior::DropInCompilerLinker::CWReleaseUnit(unitdata)
	CodeWarrior::DropInCompilerLinker::CWUnitNameToFileName(unitname, filename)
	CodeWarrior::DropInCompilerLinker::CWOSAlert(message, errorcode)
	CodeWarrior::DropInCompilerLinker::CWOSErrorMessage(msg, errorcode)
	CodeWarrior::DropInCompilerLinker::CWGetModifiedFiles(modifiedFileCount, modifiedFiles)

=cut

#use strict;

package CodeWarrior::DropInCompilerLinker;

BEGIN {
	use Exporter;

	use vars qw(@ISA @EXPORT);

	@ISA = qw(Exporter);
	@EXPORT = qw(
		CWGetContext
		CWIsPrecompiling
		CWIsAutoPrecompiling
		CWIsPreprocessing
		CWIsGeneratingDebugInfo
		CWIsCachingPrecompiledHeaders
		CWGetBrowseOptions
		CWGetBuildSequenceNumber
		CWGetTargetInfo
		CWSetTargetInfo
		CWGetTargetStorage
		CWSetTargetStorage
		CWGetMainFileNumber
		CWGetMainFileID
		CWGetMainFileSpec
		CWGetMainFileText
		CWCachePrecompiledHeader
		CWLoadObjectData
		CWFreeObjectData
		CWStoreObjectData
		CWGetSuggestedObjectFileSpec
		CWGetStoredObjectFileSpec
		CWDisplayLines
		CWGetPrecompiledHeaderSpec
		CWGetResourceFile
		CWPutResourceFile
		CWLookUpUnit
		CWSBMfiles
		CWStoreUnit
		CWReleaseUnit
		CWUnitNameToFileName
		CWOSAlert
		CWOSErrorMessage
		CWGetModifiedFiles
		DROPINCOMPILERLINKERAPIVERSION_4
		DROPINCOMPILERLINKERAPIVERSION_5
		DROPINCOMPILERLINKERAPIVERSION_6
		DROPINCOMPILERLINKERAPIVERSION_7
		DROPINCOMPILERLINKERAPIVERSION_8
		DROPINCOMPILERLINKERAPIVERSION_9
		DROPINCOMPILERLINKERAPIVERSION_10
		DROPINCOMPILERLINKERAPIVERSION
		reqTargetLinkEnded
		reqTargetLinkStarted
		reqFileListBuildEnded
		reqFileListBuildStarted
		reqSubProjectBuildEnded
		reqSubProjectBuildStarted
		reqTargetBuildEnded
		reqTargetBuildStarted
		reqProjectBuildEnded
		reqProjectBuildStarted
		reqTargetLoaded
		reqTargetPrefsChanged
		reqTargetUnloaded
		reqCompile
		reqMakeParse
		reqCompDisassemble
		reqCheckSyntax
		reqLink
		reqDisassemble
		reqTargetInfo
		reqPreRun
		filetypeText
		filetypeUnknown
		exelinkageFlat
		exelinkageSegmented
		exelinkageOverlay1
		linkOutputNone
		linkOutputFile
		linkOutputDirectory
		targetCPU68K
		targetCPUPowerPC
		targetCPUi80x86
		targetCPUMips
		targetCPUNECv800
		targetCPUEmbeddedPowerPC
		targetCPUAny
		targetOSMacintosh
		targetOSWindows
		targetOSNetware
		targetOSMagicCap
		targetOSOS9
		targetOSEmbeddedABI
		targetOSJava
		targetOSJavaMS
		targetOSJavaSun
		targetOSJavaMRJ
		targetOSJavaMW
		targetOSPalm
		targetOSAny
		cantDisassemble
		isPostLinker
		linkAllowDupFileNames
		linkMultiTargAware
		isPreLinker
		linkerUsesTargetStorage
		linkerUnmangles
		magicCapLinker
		linkAlwaysReload
		linkRequiresProjectBuildStartedMsg
		linkRequiresTargetBuildStartedMsg
		linkRequiresSubProjectBuildStartedMsg
		linkRequiresFileListBuildStartedMsg
		linkRequiresTargetLinkStartedMsg
		linkerWantsPreRunRequest
		cwAccessAbsolute
		cwAccessPathRelative
		cwAccessFileName
		cwAccessFileRelative
	);
}

# bootstrap CodeWarrior::DropInCompilerLinker is already implicitly done by your MacPerl binary

=head2 Constants

=cut

sub DROPINCOMPILERLINKERAPIVERSION_4		{	4;	}
sub DROPINCOMPILERLINKERAPIVERSION_5		{	5;	}
sub DROPINCOMPILERLINKERAPIVERSION_6		{	6;	}
sub DROPINCOMPILERLINKERAPIVERSION_7		{	7;	}
sub DROPINCOMPILERLINKERAPIVERSION_8		{	8;	}
sub DROPINCOMPILERLINKERAPIVERSION_9		{	9;	}
sub DROPINCOMPILERLINKERAPIVERSION_10		{	10;	}
sub DROPINCOMPILERLINKERAPIVERSION			{	&DROPINCOMPILERLINKERAPIVERSION_10; }

sub reqTargetLinkEnded						{	-15;	}
sub reqTargetLinkStarted					{	-14;	}
sub reqFileListBuildEnded					{	-13;	}
sub reqFileListBuildStarted					{	-12;	}
sub reqSubProjectBuildEnded					{	-11;	}
sub reqSubProjectBuildStarted				{	-10;	}
sub reqTargetBuildEnded						{	-9;	}
sub reqTargetBuildStarted					{	-8;	}
sub reqProjectBuildEnded					{	-7;	}
sub reqProjectBuildStarted					{	-6;	}
sub reqTargetLoaded							{	-5;	}
sub reqTargetPrefsChanged					{	-4;	}
sub reqTargetUnloaded						{	-3;	}

sub reqCompile								{	0;	}
sub reqMakeParse							{	1;	}
sub reqCompDisassemble						{	2;	}
sub reqCheckSyntax							{	3;	}

sub reqLink									{	0;	}
sub reqDisassemble							{	1;	}
sub reqTargetInfo							{	2;	}
sub reqPreRun								{	3;	}

sub filetypeText							{	0;	}
sub filetypeUnknown							{	1;	}

sub exelinkageFlat							{	0;	}
sub exelinkageSegmented						{	1;	}
sub exelinkageOverlay1						{	2;	}

sub linkOutputNone							{	0;	}
sub linkOutputFile							{	1;	}
sub linkOutputDirectory						{	2;	}

sub targetCPU68K							{	'68k ';	}
sub targetCPUPowerPC						{	'ppc ';	}
sub targetCPUi80x86							{	'8086';	}
sub targetCPUMips							{	'mips';	}
sub targetCPUNECv800						{	'v800';	}
sub targetCPUEmbeddedPowerPC				{	'ePPC';	}
sub targetCPUAny							{	'****';	}

sub targetOSMacintosh						{	'mac ';	}
sub targetOSWindows							{	'wint';	}
sub targetOSNetware							{	'nlm ';	}
sub targetOSMagicCap						{	'mcap';	}
sub targetOSOS9								{	'os9 ';	}
sub targetOSEmbeddedABI						{	'EABI';	}
sub targetOSJava							{	'java';	}
sub targetOSJavaMS							{	'jvms';	}
sub targetOSJavaSun							{	'jvsn';	}
sub targetOSJavaMRJ							{	'jvmr';	}
sub targetOSJavaMW							{	'jvmw';	}
sub targetOSPalm							{	'palm';	}
sub targetOSAny								{	'****';	}

sub cantDisassemble  						{	1 << 31;	}
sub isPostLinker	 						{	1 << 30;	}
sub linkAllowDupFileNames					{ 	1 << 29;	}
sub linkMultiTargAware						{	1 << 28;	}
sub isPreLinker								{	1 << 27;	}
sub linkerUsesTargetStorage					{ 	1 << 26;	}
sub linkerUnmangles							{	1 << 25;	}
sub magicCapLinker							{ 	1 << 24;	}
sub linkAlwaysReload						{ 	1 << 23;	}
sub linkRequiresProjectBuildStartedMsg   	{	1 << 22;	}
sub linkRequiresTargetBuildStartedMsg 		{	1 << 21;	}
sub linkRequiresSubProjectBuildStartedMsg 	{	1 << 20;	}
sub linkRequiresFileListBuildStartedMsg 	{	1 << 19;	}
sub linkRequiresTargetLinkStartedMsg  		{	1 << 18;	}
sub linkerWantsPreRunRequest				{	1 << 17;	}

sub cwAccessAbsolute						{	0;	}
sub cwAccessPathRelative					{	1;	}
sub cwAccessFileName						{	2;	}
sub cwAccessFileRelative					{	3;	}

=head1 AUTHOR(S)

Brad Kollmyer <bradk@directeq.com>
Scott Searle <scotts@directeq.com>

=cut

1;

__END__
