=head1 NAME

CodeWarrior - CodeWarrior::PluginErrors.

=cut

#use strict;

package CodeWarrior::PluginErrors;

BEGIN {
	use Exporter;

	use vars qw(@ISA @EXPORT);

	@ISA = qw(Exporter);
	@EXPORT = qw(
		cwNoErr
		cwErrUserCanceled
		cwErrRequestFailed
		cwErrInvalidParameter
		cwErrInvalidCallback
		cwErrInvalidMPCallback
		cwErrOSError
		cwErrOutOfMemory
		cwErrFileNotFound
		cwErrUnknownFile
		cwErrSilent
		cwErrCantSetAttribute
		cwErrLastCommonError
		cwErrUnknownSegment
		cwErrSBMNotFound
		cwErrObjectFileNotStored
		cwErrLicenseCheckFailed
		cwErrLastCompilerLinkerError
	);
}

=head2 Constants

=cut

sub cwNoErr							{	0;	}
sub cwErrUserCanceled				{	1;	}
sub cwErrRequestFailed				{	2;	}
sub cwErrInvalidParameter			{	3;	}
sub cwErrInvalidCallback			{	4;	}
sub cwErrInvalidMPCallback			{	5;	}
sub cwErrOSError					{	6;	}
sub cwErrOutOfMemory				{	7;	}
sub cwErrFileNotFound				{	8;	}
sub cwErrUnknownFile				{	9;	}
sub cwErrSilent						{	10;	}
sub cwErrCantSetAttribute			{	11;	}
sub cwErrLastCommonError			{	512;	}
sub cwErrUnknownSegment				{	513;	}
sub cwErrSBMNotFound				{	514;	}
sub cwErrObjectFileNotStored		{	515;	}
sub cwErrLicenseCheckFailed			{	516;	}
sub cwErrLastCompilerLinkerError	{	1024;	}

=head1 AUTHOR(S)

Brad Kollmyer <bradk@directeq.com>
Scott Searle <scotts@directeq.com>

=cut

1;

__END__
