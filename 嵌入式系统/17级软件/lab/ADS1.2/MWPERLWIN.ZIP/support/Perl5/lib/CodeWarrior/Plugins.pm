=head1 NAME

CodeWarrior - Built-in CodeWarrior::Plugins IDE specific routines.

=head1 SYNOPSIS

	CodeWarrior::Plugins::CWGetContext()
	CodeWarrior::Plugins::CWAddProjectEntry(spec, isGenerated=TRUE, projectEntryInfo=NULL, whichFile=NULL)
	CodeWarrior::Plugins::CWFindAndLoadFile(filename, fileinfo)
	CodeWarrior::Plugins::CWGetOutputFileDirectory(outputFileDirectory)
	CodeWarrior::Plugins::CWSetModDate(filespec, moddate, isGenerated=TRUE)
	CodeWarrior::Plugins::CWReportMessage(msgRef, line1, line2, errorlevel, errornumber)
	CodeWarrior::Plugins::CWShowStatus(line1, line2=NULL)
	CodeWarrior::Plugins::CWGetPluginRequest(request)
	CodeWarrior::Plugins::CWDonePluginRequest(resultCode)
	CodeWarrior::Plugins::CWGetAPIVersion(version)
	CodeWarrior::Plugins::CWGetIDEInfo(info)
	CodeWarrior::Plugins::CWGetCallbackOSError(error)
	CodeWarrior::Plugins::CWSetPluginOSError(error)
	CodeWarrior::Plugins::CWGetProjectFile(projectSpec)
	CodeWarrior::Plugins::CWGetTargetName(name)
	CodeWarrior::Plugins::CWGetProjectFileCount(count)
	CodeWarrior::Plugins::CWGetFileInfo(whichfile, checkFileLocation, fileinfo)
	CodeWarrior::Plugins::CWGetAccessPathListInfo(pathListInfo)
	CodeWarrior::Plugins::CWGetAccessPathInfo(pathType, whichPath, pathInfo)
	CodeWarrior::Plugins::CWGetAccessPathSubdirectory(pathType, whichPath, whichSubdirectory, subdirectory)
	CodeWarrior::Plugins::CWGetFileText(filespec, text, textLength, filedatatype)
	CodeWarrior::Plugins::CWReleaseFileText(text)
	CodeWarrior::Plugins::CWGetSegmentInfo(whichsegment, segmentinfo)
	CodeWarrior::Plugins::CWGetOverlay1GroupsCount(count)
	CodeWarrior::Plugins::CWGetOverlay1GroupInfo(whichgroup, groupinfo)
	CodeWarrior::Plugins::CWGetOverlay1Info(whichgroup, whichoverlay, overlayinfo)
	CodeWarrior::Plugins::CWGetOverlay1FileInfo(whichgroup, whichoverlay, whichoverlayfile, fileinfo)
	CodeWarrior::Plugins::CWAlert(msg1, msg2, msg3, msg4)
	CodeWarrior::Plugins::CWUserBreak()
	CodeWarrior::Plugins::CWGetNamedPreferences(prefsname, prefsdata)
	CodeWarrior::Plugins::CWStorePluginData(whichfile, type, prefsdata)
	CodeWarrior::Plugins::CWGetPluginData(whichfile, type, prefsdata)
	CodeWarrior::Plugins::CWCreateNewTextDocument(docinfo)
	CodeWarrior::Plugins::CWAllocateMemory(size, isPermanent, ptr)
	CodeWarrior::Plugins::CWFreeMemory(ptr, isPermanent)
	CodeWarrior::Plugins::CWAllocMemHandle(size, useTempMemory, handle)
	CodeWarrior::Plugins::CWFreeMemHandle(handle)
	CodeWarrior::Plugins::CWGetMemHandleSize(handle, size)
	CodeWarrior::Plugins::CWResizeMemHandle(handle, newSize)
	CodeWarrior::Plugins::CWLockMemHandle(handle, moveHi, ptr)
	CodeWarrior::Plugins::CWUnlockMemHandle(handle)
	CodeWarrior::Plugins::CWMacOSErrToCWResult(err)
	CodeWarrior::Plugins::CWPreDialog()
	CodeWarrior::Plugins::CWPostDialog()
	CodeWarrior::Plugins::CWPreFileAction(theFile)
	CodeWarrior::Plugins::CWPostFileAction(theFile)

=cut

#use strict;

package CodeWarrior::Plugins;

BEGIN {
	use Exporter;

	use vars qw(@ISA @EXPORT);

	@ISA = qw(Exporter);
	@EXPORT = qw(
		CWGetContext
		CWAddProjectEntry
		CWFindAndLoadFile
		CWGetOutputFileDirectory
		CWSetModDate
		CWReportMessage
		CWShowStatus
		CWGetPluginRequest
		CWDonePluginRequest
		CWGetAPIVersion
		CWGetIDEInfo
		CWGetCallbackOSError
		CWSetPluginOSError
		CWGetProjectFile
		CWGetTargetName
		CWGetProjectFileCount
		CWGetFileInfo
		CWGetAccessPathListInfo
		CWGetAccessPathInfo
		CWGetAccessPathSubdirectory
		CWGetFileText
		CWReleaseFileText
		CWGetSegmentInfo
		CWGetOverlay1GroupsCount
		CWGetOverlay1GroupInfo
		CWGetOverlay1Info
		CWGetOverlay1FileInfo
		CWAlert
		CWUserBreak
		CWGetNamedPreferences
		CWStorePluginData
		CWGetPluginData
		CWCreateNewTextDocument
		CWAllocateMemory
		CWFreeMemory
		CWAllocMemHandle
		CWFreeMemHandle
		CWGetMemHandleSize
		CWResizeMemHandle
		CWLockMemHandle
		CWUnlockMemHandle
		CWMacOSErrToCWResult
		CWPreDialog
		CWPostDialog
		CWPreFileAction
		CWPostFileAction
		CWPLUGIN_HOST_MACOS
		CWPLUGIN_HOST_WIN32
		CWPLUGIN_HOST
		CWPLUGIN_API_MACOS
		CWPLUGIN_API_WIN32
		CWPLUGIN_API
		reqInitialize
		reqInitialize
		reqTerminate
		reqIdle
		reqAbout
		reqPrefsChange
		cwNoDependency
		cwNormalDependency
		cwInterfaceDependency
		cwFileTypeUnknown
		cwFileTypeText
		cwFileTypePrecompiledHeader
		kCurrentCompiledFile
		kTargetGlobalPluginData
		kDefaultLinkPosition
		messagetypeInfo
		messagetypeWarning
		messagetypeError
		cwSystemPath
		cwUserPath
		CWDROPINLINKERTYPE
		CWDROPINCOMPILERTYPE
		CWDROPINPREFSTYPE
		CWDROPINPREFSTYPE_1
		CWDROPINVCSTYPE
		CWDROPINCOMTYPE
		kCurrentDropInFlagsVersion
		kCurrentCWPanelListVersion
		kCurrentCWFamilyListVersion
		kCurrentCWFamilyResourceVersion
	);
}

# bootstrap CodeWarrior::Plugins is already implicitly done by your MacPerl binary

=head2 Constants

=cut

$Is_MacOS = $^O eq 'MacOS';

sub CWPLUGIN_HOST_MACOS () 				{	1;	}
sub CWPLUGIN_HOST_WIN32 () 				{ 	2;	}

sub CWPLUGIN_HOST ()					{ 	$Is_MacOS ? CWPLUGIN_HOST_MACOS() : CWPLUGIN_HOST_WIN32(); }

sub CWPLUGIN_API_MACOS ()				{ 	1;	}
sub CWPLUGIN_API_WIN32 ()				{ 	2;	}

sub CWPLUGIN_API ()						{	$Is_MacOS ? CWPLUGIN_API_MACOS() : CWPLUGIN_API_WIN32(); }

sub	reqInitialize ()					{ -2;	}
sub	reqTerminate ()						{ -1;	}
sub	reqIdle	()							{ -100;	}
sub	reqAbout ()							{ -101;	}
sub	reqPrefsChange ()					{ -102;	}

sub cwNoDependency ()					{ 0;	}
sub cwNormalDependency ()				{ 1;	}
sub cwInterfaceDependency ()			{ 2;	}

sub cwFileTypeUnknown ()				{ 0;	}
sub cwFileTypeText ()					{ 1;	}
sub cwFileTypePrecompiledHeader ()		{ 2;	}

sub kCurrentCompiledFile ()				{ -1;	}

sub kTargetGlobalPluginData ()			{ -1;	}

sub kDefaultLinkPosition ()				{ -1;	}

sub messagetypeInfo ()					{ 0;	}
sub messagetypeWarning ()				{ 1;	}
sub messagetypeError ()					{ 2;	}

sub cwSystemPath ()						{ 0;	}
sub cwUserPath ()						{ 1;	}

sub CWDROPINLINKERTYPE ()				{ 'Link';	}
sub CWDROPINCOMPILERTYPE ()				{ 'Comp';	}
sub CWDROPINPREFSTYPE ()				{ 'PanL';	}
sub CWDROPINPREFSTYPE_1 ()				{ 'Panl';	}
sub CWDROPINVCSTYPE ()					{ 'VCS ';	}
sub CWDROPINCOMTYPE ()					{ 'COM ';	}

sub kCurrentDropInFlagsVersion ()		{ 2;	}

sub kCurrentCWPanelListVersion ()		{ 1;	}

sub kCurrentCWFamilyListVersion ()		{ 1;	}
sub kCurrentCWFamilyResourceVersion ()	{ 1;	}

=head1 AUTHOR(S)

Brad Kollmyer <bradk@directeq.com>
Scott Searle <scotts@directeq.com>

=cut

1;

__END__
