    ######################################################

    # Company : ActiveState Tool Corp.
    # Author  : James A. Snyder ( James@ActiveState.com )
    # Date    : 7/11/98
	# Copyright � 1998 ActiveState Tool Corp., all rights reserved.
	#

    ######################################################

    # MetabaseConfig.pm

    package MetabaseConfig;
    use Win32::OLE;
	use strict;
	
    ######################################################

    # ScriptMap flags

    sub MD_SCRIPTMAPFLAG_SCRIPT_ENGINE{1};
    sub MD_SCRIPTMAPFLAG_CHECK_PATH_INFO{4};

    ######################################################

    # Access Permission Flags

    sub MD_ACCESS_READ               { 0x00000001 }; #   // Allow for Read
    sub MD_ACCESS_WRITE              { 0x00000002 }; #   // Allow for Write
    sub MD_ACCESS_EXECUTE            { 0x00000004 }; #   // Allow for Execute
    sub MD_ACCESS_SCRIPT             { 0x00000200 }; #   // Allow for Script execution
    sub MD_ACCESS_NO_REMOTE_WRITE    { 0x00000400 }; #   // Local host access only
    sub MD_ACCESS_NO_REMOTE_READ     { 0x00001000 }; #   // Local host access only
    sub MD_ACCESS_NO_REMOTE_EXECUTE  { 0x00002000 }; #   // Local host access only
    sub MD_ACCESS_NO_REMOTE_SCRIPT   { 0x00004000 }; #   // Local host access only

    ######################################################


    # StartWWW( $dwWebServerID );

    sub StartWWW
    {
        my $serverID = $_[0];
        my $path   = 'IIS://localhost/W3SVC/' . $serverID;
        my $server =  Win32::OLE->GetObject($path)
            || print "Could not GetObject($path}\n";
        $server->Start();
    }

    ######################################################

    # StopWWW( $dwWebServerID );

    sub StopWWW
    {
        my $serverID = $_[0];
        my $path   = 'IIS://localhost/W3SVC/' . $serverID;
        my $server =  Win32::OLE->GetObject($path)
            || print "Could not GetObject($path}\n";
        $server->Stop();
    }

    ######################################################

    # $arrayRef = EnumWebServers();

    sub EnumWebServers
    {
        my $index = 1;
        my $path = 'IIS://localhost/W3SVC/';
        my $testPath = $path . $index;
        my $server;
        my @webServers = ();

        while ( ($server=Win32::OLE->GetObject($testPath)) )
        {
            $webServers[$index] = $server->{ServerComment};
            $index++;
            $testPath = $path . $index;
        }

        return \@webServers;
    }

    ######################################################

    # GetFileExtMapping($dwServerID, $szVirDir, $szFileExt)

    sub GetFileExtMapping
    {
        if( @_ < 3 )
        {
            die "Not enough Parameters for GetFileExtMapping()\n";
        }

        my $server        = '';
        my $szVirDirPath  = '';
        my $dwServerID    = shift;
        my $szVirDir      = shift;
        my $szFileExt     = shift;
		my $scriptMap	  = '';

        # Create string that contains the Path to our Virutal directory or the WebServer's Root
        $szVirDirPath = 'IIS://localhost/W3SVC/' . $dwServerID . '/ROOT';
        if( length($szVirDir) )
        {
            $szVirDirPath = $szVirDirPath . "/" . $szVirDir;
        }

        # Get the IIsVirtualDir Automation Object
        ($server = Win32::OLE->GetObject($szVirDirPath))
               ||  return "Error: Could not GetObject($szVirDirPath) \n";

		foreach $scriptMap (@{$server->{ScriptMaps}}) {
			if($scriptMap =~ /^$szFileExt,/i) {
				return $scriptMap;
			}
		}
    }


    ######################################################

    # RemoveFileExtMapping($dwServerID, $szVirDir, $szFileExt)

    sub RemoveFileExtMapping
    {
        if( @_ < 3 )
        {
            die "Not enough Parameters for AddFileExtMapping()\n";
        }

        my $szVirDirPath    = '';
        my @newScriptMap  = ();
        my $dwServerID    = shift;
        my $szVirDir      = shift;
        my $szFileExt     = shift;
        my $virDir;
		my $ScriptMap	  = '';

		if(GetFileExtMapping($dwServerID, $szVirDir, $szFileExt) eq '') {
			return 1;
		}

        # Create string that contains the Path to our Virutal directory or the WebServer's Root
        $szVirDirPath = 'IIS://localhost/W3SVC/' . $dwServerID . '/ROOT';
        if( length($szVirDir) )
        {
            $szVirDirPath = $szVirDirPath . "/" . $szVirDir;
        }

        # Get the IIsVirtualDir Automation Object
        ($virDir = Win32::OLE->GetObject($szVirDirPath))
            || return "Error: Could not GetObject($szVirDirPath) \n";

		foreach $ScriptMap (@{$virDir->{ScriptMaps}}) {
		    if($ScriptMap !~ /^$szFileExt,/i) {
		        push(@newScriptMap, $ScriptMap);
		    }
		}

        # set the ScriptsMaps property to our new script map array
        $virDir->{ScriptMaps} = \@newScriptMap;

        # Save the new script mappings
        $virDir->SetInfo();
    }

    ######################################################

    # AddFileExtMapping($dwServerID, $szVirDir, $szFileExt, $lpszExec, $dwFlags, $szMethodExclusions)

    sub AddFileExtMapping
    {
        if( @_ < 6 )
        {
            die "Not enough Parameters for AddFileExtMapping()\n";
        }

        my $server        = '';
        my $szVirDirPath    = '';
        my $scriptMapping = '';
        my @newScriptMap  = ();
        my $dwServerID    = shift;
        my $szVirDir      = shift;
        my $szFileExt     = shift;
        my $szExecPath    = shift;
        my $dwFlags       = shift;
        my $szMethodExc   = shift;

		if(GetFileExtMapping($dwServerID, $szVirDir, $szFileExt) ne '') {
			return 1;
		}
		
        # Create string that contains the Path to our Virutal directory or the WebServer's Root
        $szVirDirPath = 'IIS://localhost/W3SVC/' . $dwServerID . '/ROOT';
        if( length($szVirDir) )
        {
            $szVirDirPath = $szVirDirPath . "/" . $szVirDir;
        }

        # Get the IIsVirtualDir Automation Object
        ($server = Win32::OLE->GetObject($szVirDirPath))
                || return "Error: Could not GetObject($szVirDirPath) \n";

        # create our new script mapping entry
        $scriptMapping = "$szFileExt,$szExecPath,$dwFlags";

        # make sure the length of szMethodExc is greater than 2 before adding szMethodExc to the script mapping
        if( length($szMethodExc) > 2 )
        {
            $scriptMapping = $scriptMapping . ",$szMethodExc";
        }

		@newScriptMap = @{$server->{ScriptMaps}};
		push(@newScriptMap, $scriptMapping);
		
		$server->{ScriptMaps} = \@newScriptMap;

        # Save the new script mappings
        $server->SetInfo();
    }

    ######################################################

    # CreateVirDir( $dwServerID, $szPath, $szName, $dwAccessPerm, $bEnableDirBrowse, $bAppRoot);

    sub CreateVirDir
    {
        if( @_ < 6 )
        {
            die "Not enough Parameters for CreateVirDir()\n";
        }

        # Local Variables
        my $serverPath;
        my $server;
        my $virDir;
        my $dwServerID       = shift;
        my $szPath           = shift;
        my $szName           = shift;
        my $dwAccessPerm     = shift;
        my $bEnableDirBrowse = shift;
        my $bAppRoot         = shift;


        if($szPath eq "" || $szName eq "")
        {
            die "Incorrect Parameter to CreateVirDir() ...\n";
        }

        # Create string that contains the Path to our Webserver's Root
        my $serverPath = 'IIS://localhost/W3SVC/' . $dwServerID . '/Root';

        # Get the IIsWebServer Automation Object
        (my $server = Win32::OLE->GetObject($serverPath))
            || return "Error: Could not GetObject($serverPath) \n";

        # Create Our Virutual Directory or get it if it already exists
        $virDir = $server->Create('IIsWebVirtualDir', $szName);
        if( not UNIVERSAL::isa($virDir, 'Win32::OLE') )
        {
            $virDir = $server->GetObject('IIsWebVirtualDir', $szName)
                or  print Win32::OLE->LastError() . "\n";
        }

        $virDir->{Path}                  = $szPath;
        $virDir->{AppFriendlyName}       = $szName;
        $virDir->{EnableDirBrowsing}     = $bEnableDirBrowse;
        $virDir->{AccessRead}            = $dwAccessPerm & MD_ACCESS_READ;
        $virDir->{AccessWrite}           = $dwAccessPerm & MD_ACCESS_WRITE;
        $virDir->{AccessExecute}         = $dwAccessPerm & MD_ACCESS_EXECUTE;
        $virDir->{AccessScript}          = $dwAccessPerm & MD_ACCESS_SCRIPT;
        $virDir->{AccessNoRemoteRead}    = $dwAccessPerm & MD_ACCESS_NO_REMOTE_READ;
        $virDir->{AccessNoRemoteScript}  = $dwAccessPerm & MD_ACCESS_NO_REMOTE_SCRIPT;
        $virDir->{AccessNoRemoteWrite}   = $dwAccessPerm & MD_ACCESS_NO_REMOTE_WRITE;
        $virDir->{AccessNoRemoteExecute} = $dwAccessPerm & MD_ACCESS_NO_REMOTE_EXECUTE;

        $virDir->AppCreate($bAppRoot);
        $virDir->SetInfo();
    }

    ######################################################

    # DeleteVirDir( $dwServerID, $szVirDir );

    sub DeleteVirDir
    {
        my $dwServerID = $_[0];
        my $szVirDir   = $_[1];
        my $szPath     = '';
        my $server     = '';

        if($dwServerID eq "" || $szVirDir eq "")
        {
            die "Incorrect Parameter to DeleteVirDir() ...\n";
        }

        # Create string that contains the Path to our Webserver's Root
        my $szPath = 'IIS://localhost/W3SVC/' . $dwServerID . '/Root';

        # Get the IIsWebServer Automation Object
        (my $server = Win32::OLE->GetObject($szPath))
            || return "Error: Could not get the IIsWebServer: ($szPath) \n";

        $server->Delete( "IIsWebVirtualDir", $szVirDir );
        $server->SetInfo();
    }


1;