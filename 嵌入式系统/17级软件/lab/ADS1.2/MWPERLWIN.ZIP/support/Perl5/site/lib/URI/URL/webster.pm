package URI::URL::webster;
require URI::URL::_generic;
@ISA = qw(URI::URL::_generic);

sub default_port { 765 }
1;
