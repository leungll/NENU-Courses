#!/bin/sh 
#
# Remove FLEXlm tools links
#
# Copyright (c) ARM Limited 2000, 2001. All rights reserved
#

PATH=/usr/ucb:/usr/bin:/bin; export PATH

rm -f lmhostid lmver lmcksum lmdown lmremove lmreread lmswitchr lmstat lmdiag lminstall

