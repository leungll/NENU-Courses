      function f=fun3(x);
     f=-x(1)-2*x(2)+(1/2)*x(1)^2+(1/2)*x(2)^2
     