function f=fun(x);
f=-2*x(1)-x(2);
