load gas
price2
[h,sig,ci] = ttest( price2 ,115)