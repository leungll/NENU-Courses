load dj
[muhat,sigmahat,muci,sigmaci] = normfit(x)