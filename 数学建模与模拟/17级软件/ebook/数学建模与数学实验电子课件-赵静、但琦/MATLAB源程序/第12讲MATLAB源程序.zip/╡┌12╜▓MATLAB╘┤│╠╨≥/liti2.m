x=-6:0.01:6; 
y=normpdf(x); z=normpdf(x,0,2);
plot(x,y,x,z)