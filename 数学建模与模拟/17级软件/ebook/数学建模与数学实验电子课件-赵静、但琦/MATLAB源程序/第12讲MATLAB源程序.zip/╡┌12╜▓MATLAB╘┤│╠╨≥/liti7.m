   load  gas
    price1
   [h,sig,ci] = ztest(price1,115,4)