load dj
hist(x,10)