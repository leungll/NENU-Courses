load gas
[h,sig,ci] = ttest2(price1,price2)