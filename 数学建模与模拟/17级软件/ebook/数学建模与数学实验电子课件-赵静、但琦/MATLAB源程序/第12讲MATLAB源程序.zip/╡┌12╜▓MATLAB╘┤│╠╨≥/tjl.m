load data1
x=data(2,:)
mean=mean(x)
median=median(x)
std=std(x)
var=var(x)
skewness=skewness(x)
kurtosis=kurtosis(x)