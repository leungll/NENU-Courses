load dj
[h,sig,ci] = ttest( x ,594)