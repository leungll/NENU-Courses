load dj
normplot(x)