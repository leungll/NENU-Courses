x=randn(50,3);y=x*[-1 2 1;2 0 1;1 -2 3];
plotmatrix(y,'*r')