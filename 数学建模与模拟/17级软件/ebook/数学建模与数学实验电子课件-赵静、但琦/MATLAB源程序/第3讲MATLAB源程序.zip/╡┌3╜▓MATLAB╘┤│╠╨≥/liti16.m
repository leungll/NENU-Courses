x=linspace(-2.5,2.5,20);                 
        y=exp(-x.*x);
        bar (x,y)
        title('bar plot of a bell crure');