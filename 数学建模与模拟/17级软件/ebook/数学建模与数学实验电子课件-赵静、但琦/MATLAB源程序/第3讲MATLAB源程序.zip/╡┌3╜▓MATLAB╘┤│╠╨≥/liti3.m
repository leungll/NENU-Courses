x=linspace(0,2*pi,30);
 y=sin(x);
 z=cos(x);
 plot(x,y,x,z)
 gtext('sin(x)');
 gtext('cos(x)');