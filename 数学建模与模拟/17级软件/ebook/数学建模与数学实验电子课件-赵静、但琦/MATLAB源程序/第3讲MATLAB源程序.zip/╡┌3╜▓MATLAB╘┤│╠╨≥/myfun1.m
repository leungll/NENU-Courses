function y=myfun1(x)
y=exp(2*x)+sin(3*x^2)