load seamount
scatter(x,y,5,z)