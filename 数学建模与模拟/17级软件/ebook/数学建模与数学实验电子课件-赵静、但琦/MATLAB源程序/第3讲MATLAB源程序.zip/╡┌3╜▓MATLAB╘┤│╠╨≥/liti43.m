fplot('myfun1',[-1,2])
