x=linspace(0.0001,0.01,1000);
 y=sin(1./x);
 plot(x,y)
 axis([0.005 0.01 -1 1])