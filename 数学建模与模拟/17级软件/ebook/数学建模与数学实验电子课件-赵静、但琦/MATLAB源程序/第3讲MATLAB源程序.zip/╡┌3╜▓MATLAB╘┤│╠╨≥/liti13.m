x=linspace(0,2*pi,30);

y=sin(x);

plot(x,y)
 zoom  on