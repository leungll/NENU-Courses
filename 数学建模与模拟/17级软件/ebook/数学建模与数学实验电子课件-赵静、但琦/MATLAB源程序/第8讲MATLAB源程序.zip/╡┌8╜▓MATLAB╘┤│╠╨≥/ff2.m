y=dsolve('D2y+4*Dy+29*y=0','y(0)=0,Dy(0)=15','x')
