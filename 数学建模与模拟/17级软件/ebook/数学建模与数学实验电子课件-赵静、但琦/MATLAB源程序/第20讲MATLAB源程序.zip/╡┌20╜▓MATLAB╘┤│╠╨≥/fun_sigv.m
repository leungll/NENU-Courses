function y=fun_sigv(x)
y=x.*cos(5*pi*x)+3.5;
