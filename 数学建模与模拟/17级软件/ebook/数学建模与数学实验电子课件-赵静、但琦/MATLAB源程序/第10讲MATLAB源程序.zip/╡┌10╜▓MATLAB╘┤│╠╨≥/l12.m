load xyz
meshz(x,y,z),rotate3d
xlabel('X'),ylabel('Y'),zlabel('Z')
hold on;
plot3(2000,2800,1100,'c.',0,800,650,'r.',4000,2000,950,'r.',2000,4000,1320,'r.','MarkerSize',30);
