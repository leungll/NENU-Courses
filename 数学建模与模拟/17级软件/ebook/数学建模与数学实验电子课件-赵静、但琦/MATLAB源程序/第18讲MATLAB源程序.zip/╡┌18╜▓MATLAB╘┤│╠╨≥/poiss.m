n1=poissrnd(4)
n2=poissrnd(4)
n3=poissrnd(4)
n=n1+n2+n3