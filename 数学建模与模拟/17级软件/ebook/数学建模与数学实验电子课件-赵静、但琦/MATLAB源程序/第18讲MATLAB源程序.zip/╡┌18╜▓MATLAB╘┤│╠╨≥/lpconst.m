function lpc=lpconst(x)
if 3*x(1)+x(2)-10<=0.5 & 3*x(1)+x(2)-10>=-0.5
   lpc=1;
else
   lpc=0;
end 
