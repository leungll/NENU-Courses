rand
rand(5,3)


unifrnd(1,32,1,7)

normrnd(70,25,1,50)



