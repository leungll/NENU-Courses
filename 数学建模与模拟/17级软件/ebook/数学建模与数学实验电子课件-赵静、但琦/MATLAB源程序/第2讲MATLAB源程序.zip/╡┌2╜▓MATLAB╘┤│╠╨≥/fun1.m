function f=fun1(x)
if x>1
   f=x^2+1
end
if x<=1
   f=2*x
end
