a=[1 2 3 4]
c=2
a1=a+c
a2=a*c
a3=a./c
a4=a.\c
a5=a.^c
a6=c.^a
