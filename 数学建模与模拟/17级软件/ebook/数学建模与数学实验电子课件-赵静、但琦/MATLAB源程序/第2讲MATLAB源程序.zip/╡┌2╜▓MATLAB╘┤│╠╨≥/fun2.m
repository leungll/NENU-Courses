function f=fun2(x)
if x>1
   f=x^2+1
else if x<=0
      f=x^3
   else
      f=2*x
   end
end

   
      