a=[1 2 3
   4 5 6]
b=[1 2
   1 2
   1 2]
c1=a+a
c2=a*b
c=[2 7 3;3 9 4;1 5 3]
c3=det(c)
c4=inv(c)
[v,d]=eig(c)