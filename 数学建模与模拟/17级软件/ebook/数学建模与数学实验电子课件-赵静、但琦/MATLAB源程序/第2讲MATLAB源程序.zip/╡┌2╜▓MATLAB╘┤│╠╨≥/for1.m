for n=1:10
   x(n)=sin(n*pi/10);
end
x