money=10000
years=0
while money<20000
   years=years+1
   money=money*(1+11.25/100)
end
