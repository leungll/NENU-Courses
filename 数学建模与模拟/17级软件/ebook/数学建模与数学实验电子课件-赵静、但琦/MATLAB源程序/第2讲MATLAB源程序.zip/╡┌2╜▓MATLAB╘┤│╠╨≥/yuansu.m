a=[3 5 7 -3 5 32];
b=[1 2 3 4 5 6]
c=5;
a+b
a+c
a*c
a.*b
a./b
a.\b
a.^b
a.^c
c.^a
