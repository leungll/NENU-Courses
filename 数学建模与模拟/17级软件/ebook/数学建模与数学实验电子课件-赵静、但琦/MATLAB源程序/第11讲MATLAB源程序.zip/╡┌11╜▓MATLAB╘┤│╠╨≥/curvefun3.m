function f=curvefun3(x,tdata)
d=300
f=(x(1)\d)*exp(-x(2)*tdata)   
% x(1)=v; x(2)=k
  